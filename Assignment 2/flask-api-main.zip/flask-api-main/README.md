# flask-api

Simple Flask API  to test GET, POST, DELETE and PUT request

Clone this Repo

```
  git clone git@github.com:kshyam/flask-api.git

```

```
 flask --debug run 

```

Access form POSTMAN at 

```
http://localhost:5000/api

```
